package com.error404.geulbut.jpa.books.controller;


import com.error404.geulbut.jpa.books.dto.BookApiDto;
import com.error404.geulbut.jpa.books.service.BookApiService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

// 화면용 컨트롤러: JSP 반환
//화면출력주소 : http://localhost:8080/books/1
@Controller
@RequiredArgsConstructor
@RequestMapping("/books") // 예: /books/123, /books/123?format=Hardcover
public class BookViewController {

    private final BookApiService bookApiService;

    // 북 디테일
    @GetMapping("/{bno}")
    public String bookDetail(@PathVariable Long bno,
                             @RequestParam(required = false) String format,
                             Model model) {
// 아직 코딩 안됨
//        BookApiDto book = bookApiService.getByBno(bno);
//
//        // 선택된 포맷이 있으면 주입(옵션)
//        if (format != null) {
//            book.setFormat(format);
//        }

//        model.addAttribute("book", book);
        return "books/book_detail"; // /WEB-INF/views/shop/bookDetail.jsp 로 포워딩(뷰리졸버 기준)
    }
}
