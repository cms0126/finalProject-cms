package com.error404.geulbut.common;

public class SecurityUtil {
}
