package com.error404.geulbut.jpa.notice.entity;

public class Notice {
}
