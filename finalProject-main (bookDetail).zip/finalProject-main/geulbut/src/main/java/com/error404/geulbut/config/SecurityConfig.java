package com.error404.geulbut.config;

import com.error404.geulbut.jpa.users.service.CustomOAuth2UserService;
import jakarta.servlet.DispatcherType;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

//private final CustomOAuth2UserService customOAuth2UserService;

//    비밀번호 인코더 등록 9/11
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
    }

//    개발 중 임시 전체 오픈 스위치(true = 전체허용, false = 원래보안)
    private static final boolean DEV_BYPASS = true;


    @Bean
    SecurityFilterChain filterChain(HttpSecurity http,
                                    CustomOAuth2UserService customOAuth2UserService) throws Exception {
        // 👆 Bean 메서드 파라미터 주입 방식으로 변경

        if (DEV_BYPASS) {
            http
                    .authorizeHttpRequests(auth->auth
                            .requestMatchers("/oauth2/**").permitAll()
                            .anyRequest().permitAll()
                    )
                    .oauth2Login(oauth ->oauth
                            .loginPage("/login")
                    )
                    .csrf(AbstractHttpConfigurer::disable)
                    .headers(headers->headers.frameOptions(frame->frame.sameOrigin()))
                    .logout(logout -> logout
                            .logoutUrl("/logout")
                            .logoutSuccessUrl("/")
                            .invalidateHttpSession(true)
                            .deleteCookies("JSESSIONID")
                    );
            return http.build();
        }

        http
                .authorizeHttpRequests(auth->auth
                        .dispatcherTypeMatchers(DispatcherType.FORWARD, DispatcherType.ERROR)
                        .permitAll()
                        .dispatcherTypeMatchers(DispatcherType.INCLUDE).permitAll()

                        .requestMatchers(
                                "/", "/ping",
                                "/login", "/login/**",
                                "/oauth2/**", "/login/oauth2/**",
                                "/css/**", "/js/**", "/images/**", "/webjars/**",
                                "/favicon.ico", "/error",
                                "dustApi", "DustWeatherApi","/v/**", "/dust","weather","weatherApi",
                                "admin/css/admin-header.css"
                        ).permitAll()

                        .anyRequest().authenticated()
                )
                .formLogin(form->form
                        .loginPage("/login")
                        .loginProcessingUrl("/loginProc")
                        .usernameParameter("username")
                        .passwordParameter("password")
                        .defaultSuccessUrl("/", false)
                        .failureUrl("/login?error")
                        .permitAll()
                )
                .oauth2Login(oauth->oauth
                        .loginPage("/login")
                        .defaultSuccessUrl("/", false)
                        .failureUrl("/login?error")
                        .userInfoEndpoint(cfg->cfg.userService(customOAuth2UserService)) // ✅ 여기서 파라미터로 받은 서비스 사용
                )
                .logout(logout->logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                )
                .csrf(csrf->csrf.disable())
                .headers(h->h.frameOptions(f->f.sameOrigin()));

        return http.build();
    }
}
